import mayflower.*;
public class MovableAnimatedActor extends AnimatedActor
{
    // instance variables - replace the example below with your own
    private Animation walkRight;
    private Animation walkLeft;
    private Animation idle;
    private String currentAction;
    private String direction;

    /**
     * Constructor for objects of class MovableAnimatedActor
     */
    public MovableAnimatedActor()
    {
        // initialise instance variables
        walkRight = null;
        walkLeft = null;
        idle = null;
        currentAction = null;
        direction = "right";
    }

    public void act(){
        super.act();
        int x = getX();
        int y = getY();
        int w = getWidth();
        int h = getHeight();
        int speed = 1;
        String newAction = null;
        if(currentAction == null){
            newAction = "idle";
        }
        if (Mayflower.isKeyDown(Keyboard.KEY_RIGHT) && ((x+w+speed) <= 800)){
            setLocation(x + speed, y);
            if(isTouching(Block.class))
            {
                setLocation(x-speed, y);
            }
            direction = "right";
            newAction = "walkRight";
        }
        else if (Mayflower.isKeyDown(Keyboard.KEY_LEFT) && ((x-speed) >= 0)){
            setLocation(x - speed, y);
            if(isTouching(Block.class))
            {
                setLocation(x+speed, y);
            }
            direction = "left";
            newAction = "walkLeft";
        }
        else if (Mayflower.isKeyDown(Keyboard.KEY_UP) && ((y-speed)>=0)){
            setLocation(x, y-speed);
        }
        else if (Mayflower.isKeyDown(Keyboard.KEY_DOWN) && ((y+h+speed) <= 600)){
            setLocation(x, y+speed);
        }

        if((newAction != null) && (!newAction.equals(currentAction))){
       
            if(newAction.equals("walkRight")){
                setAnimation(walkRight);
            }
            else if(newAction.equals("walkLeft")){
                setAnimation(walkLeft);
            }
    
            else{
                setAnimation(idle);
            }
        }
    }

    public void setWalkRightAnimation(Animation ani)
    {
        walkRight = ani;
    }

    public void setWalkLeftAnimation(Animation ani)
    {
        walkLeft = ani;
    }
    
    public void setIdleAnimation(Animation ani)
    {
        idle = ani;
    }
}



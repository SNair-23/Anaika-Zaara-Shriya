
/**
 * Write a description of class GameOver here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import mayflower.*;
public class GameOver extends MyWorld
{
    // instance variables - replace the example below with your own

    /**
     * Constructor for objects of class GameOver
     */
    public GameOver()
    {
        // initialise instance variables
        super(TypeWorld.Win,"img/BG/black.png");
        showText("Press SPACE to play again!!", 100, 100);
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void act()
    {
        // put your code here
        if (Mayflower.isKeyDown(Keyboard.KEY_SPACE)) {
            StarterScreen game = new StarterScreen();
            Mayflower.setWorld(game);
        }
    }
}
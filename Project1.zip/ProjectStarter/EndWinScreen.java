
import mayflower.*;
public class EndWinScreen extends MyWorld
{
  
    public EndWinScreen()
    {
        super(TypeWorld.Win,"img/BG/YouWinScreen.png");
        showText("YOU WIN!!", 300, 150, Color.WHITE);

    }
  
    public void act()
    {
         if (Mayflower.isKeyDown(Keyboard.KEY_D)){
            GameOver game = new GameOver();
            Mayflower.setWorld(game);
            
        }
    }
}

/**
 *
 * @Zaara I (your name)
 * @version (a version number or a date)
 */
import mayflower.*;

public class LandWorld extends MyWorld {
    private Cat landMonkey;
    private boolean start;
    private boolean didLose;
    // Jump & gravity
    private boolean isJumping = false;
    private int jumpVelocity = 0;
    private final int GRAVITY = 1;
    private final int JUMP_STRENGTH = 15;

    // Side-scrolling
    private int cameraX = 0;

    public LandWorld() {
        super(TypeWorld.Land, "img/BG/img.jpg", new String[6][32], 2, 5);
        landMonkey = super.getCat();
        landMonkey.setLocation(100, 350); // start higher so it doesn't touch objects immediately
        lives = 3;
        score = 0;
    }

    public boolean isStarted() {
        return Mayflower.isKeyDown(Keyboard.KEY_W);
    }

    @Override
    public void buildWorld() {
        super.buildWorld();
        for (int row = 0; row < tiles.length; row++) {
            for (int col = 0; col < tiles[row].length; col++) {
                if (tiles[row][col].equals("pig")) {
                    int groundY = getGroundYForColumn(col);
                    int pigY = groundY - 40;
                    addObject(new Pig(true), col * 100, pigY);
                }
                if (tiles[row][col].equals("banana")) {
                    addObject(new Banana(false), col * 100, row * 100);
                }
            }
        }
        addObject(new Cliff(landMonkey), 30*100, 2*100);
    }

    private int getGroundYForColumn(int col) {
        for (int row = tiles.length - 1; row >= 0; row--) {
            if (tiles[row][col].equals("ground") || tiles[row][col].equals("block")) {
                return row * 100;
            }
        }
        return tiles.length * 100;
    }

    @Override
    public void addRandomObjects() {
        super.addRandomObjects();
        for (int row = 0; row < tiles.length - 1; row++) {
            for (int col = 0; col < tiles[row].length; col++) {
                int rand = (int) (Math.random() * 10);
                if ((rand < 3) && tiles[row][col].equals("") &&
                        (tiles[row + 1][col].equals("ground") || tiles[row + 1][col].equals("block"))) {
                    tiles[row][col] = "pig";
                }

                rand = (int) (Math.random() * 10);
                if ((rand < 4) && tiles[row][col].equals("") &&
                        (tiles[row + 1][col].equals("ground") || tiles[row + 1][col].equals("block"))) {
                    tiles[row][col] = "banana";
                }
            }
        }
    }
    public boolean gameLose()
    {
        if(lives == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public boolean goToLose(){
        if (gameLose()) {
            didLose = true;

        }
        else 
        {
            didLose = false;
        }

        return didLose;
    }
    @Override
    public void act() {
        super.act();

        showText("Lives: " + lives, 10, 60, Color.BLACK);
        

        int x = landMonkey.getX();
        int y = landMonkey.getY();
        int groundY = 418;
            
        if(landMonkey.isTouchingObject() == WorldObject.Cliff){
            /**
            while(y > 250){
            landMonkey.setLocation(x+1, y+1);
            }
            if(y<250){
                
                SeaWorld water = new SeaWorld();
                Mayflower.setWorld(water);
            }
            
            */
            SeaWorld water = new SeaWorld();
            Mayflower.setWorld(water);
            start = false;
        }
        
        // Jump
        if (!isJumping && Mayflower.isKeyDown(Keyboard.KEY_SPACE)) {
            isJumping = true;
            jumpVelocity = -JUMP_STRENGTH;
        }

        if (isJumping) {
            y += jumpVelocity;
            jumpVelocity += GRAVITY;

            if (y >= groundY) {
                y = groundY;
                isJumping = false;
                jumpVelocity = 0;
            }
            landMonkey.setLocation(x, y);
        }

        // Left/Right movement with side-scrolling
        int centerX = 400;
        if (Mayflower.isKeyDown(Keyboard.KEY_RIGHT)) {
            landMonkey.setWalkRight();
            if (x < centerX) {
                x += 5;
            } else {
                cameraX += 5;
                for (Actor obj : getObjects(Actor.class)) {
                    if (obj != landMonkey) obj.setLocation(obj.getX() - 5, obj.getY());
                }
            }
        } else if (Mayflower.isKeyDown(Keyboard.KEY_LEFT)) {
            landMonkey.setWalkLeft();
            if (x > centerX) {
                x -= 5;
            } else {
                cameraX -= 5;
                for (Actor obj : getObjects(Actor.class)) {
                    if (obj != landMonkey) obj.setLocation(obj.getX() + 5, obj.getY());
                }
            }
        } else if (!isJumping) {
            landMonkey.setIdle();
        }

        landMonkey.setLocation(x, y);

        // Collect bananas
        for (Actor banana : getObjects(Banana.class)) {
            if (landMonkey.isTouchingObject()==WorldObject.Banana) {
                removeObject(banana);
                MyWorld.addPoint();
                break;
            }
        }

        // Hit pigs
        for (Actor pig : getObjects(Pig.class)) {
            if (landMonkey.isTouchingObject()== WorldObject.Pig) {
                removeObject(pig);
                MyWorld.remLife();
                break;
            }
        }
        if(goToLose()){
            EndLoseScreen lose = new EndLoseScreen();
            Mayflower.setWorld(lose);
            didLose = false;
        }
    
        // Move to next world
        if (isStarted()) {
            SeaWorld water = new SeaWorld();
            Mayflower.setWorld(water);
            start = false;
        }
    }
}



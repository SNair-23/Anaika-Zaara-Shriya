
/**
 * Cliff is the oject seen at the end of land world used for the monkey to climb to the SeaWorld!
 * 
 * @Shriya Nair
 * @version (a version number or a date)
 */
import mayflower.*;
public class Cliff extends Actor
{
    // instance variables - replace the example below with your own
    private MayflowerImage img;
    private Cat monkey;
    //Constructor: takes in the landMonkey as parameter to later increment its location
    public Cliff(Cat landMonkey)
    {
        monkey = landMonkey;
        img = new MayflowerImage("img/BG/cliff.png");
        img.scale(200,400);
        img.mirrorHorizontally();
        setImage(img);
        
    }
    
    //This manipulates the monkey's location when it touches the cliff! 
    public void act()
    {
        
    }
  
}
/**
 * SkyWorld is a class that creates a world with the background of a sky.
 * It will have the actor falling through the sky and dodging clouds and earning points through bananas.
 * If the player is "attacked" by a cloud, or carried off screen (y<0), then the player loses 1 of 3 lives.
 * Once the player reaches the bottom of the skyworld, the world is changed to LandWorld.
 * 
 * 
 * @Shriya N
 */
import mayflower.*;
public class SkyWorld extends MyWorld
{
    // instance variables
    private boolean start; //bypass to go to next world without completing
    private Cat skyMonkey; 
    private boolean falling;
    private int countFall;
    private int lives;
    
    //instantiates instance variables by creating new world Sky, assinging same monkey from MyWorld to skyMonkey, and setting other variables
    public SkyWorld()
    {
        //create a skyworld and place the monkey on screen
        super(TypeWorld.Sky, "img/BG/Sky_Blue.png", new String[30][7], 300, 200);
        addRandomObjects();
        skyMonkey = super.getCat();

        start = false; //bypass
        countFall = 0; 
        lives = 3;
    }

    //The isStarted method is a development assistor to transition between worlds when testing
    //It is not intended to be used by a player of the game
    public boolean isStarted(){
        if (Mayflower.isKeyDown(Keyboard.KEY_D)) {
            start = true;

        }
        else{
            start = false;
        }
        return start;
    }

    //adds Cloud and Banana strings to a 2-D array from MyWorld --- Ground was added in MyWorld
    public void addRandomObjects(){
        for(int row=0; row<tiles.length-1;row++){
            for(int col=0; col<tiles[row].length; col++){
                int rand = (int)(Math.random()*(tiles[0].length));
                if((rand < 1) && tiles[row][col] == ""){ 
                    tiles[row][col] = "banana";
                }
            }
        }
        for(int row=1; row<tiles.length-1;row++){
            for(int col=0; col<tiles[row].length; col++){
                if(row<3 && col<5){ 
                    tiles[row][col] = " ";

                }
                int rand = (int)(Math.random()*(tiles[0].length));
                if((rand < 1) && (tiles[row][col] == "")){
                    tiles[row][col] = "cloud";
                }
            }
        }
    }

    //adds objects to the screen from 2-D array
    @Override
    public void buildWorld(){

        //adding the initial cloud platform for rest
        Cloud a = new Cloud(this, false);
        Cloud b = new Cloud(this, false);
        addObject(a, 0, 100);
        addObject(b, 100, 100);

        //attempts to remove the platform if the monkey is off of it
        if(countFall >= 1){
            super.buildWorld();
            a.removeCloud();
            b.removeCloud();
        }

        //if the monkey is off of the platform- recreate the world so that cloud and banana and block objects are moving up, creating the falling illusion
        if(countFall == 1){
            for(int row=0; row < tiles.length; row++){
                for(int col=0; col < tiles[row].length; col++){

                    if(tiles[row][col].equals("cloud")){
                        addObject(new Cloud(this, true), col * 100, row * 100);
                    }
                    if(tiles[row][col].equals("banana")){
                        addObject(new Banana(true), col * 100, row * 100);
                    }
                    if(tiles[row][col].equals("ground")){
                        addObject(new Block(true), col * 100, row * 100);
                    }

                }

            }
        }
    }

    public void loseLife(int x){
        lives -= x;
        skyMonkey.setLocation(400,300);
    }

    public int numLives(){
        return lives;
    }

        public int checkIfFalling(int x)
    {
        if(x > 200) //x>platform length
            {
                countFall += 1;
            }
        else //only when monkey is on platform
            {
                countFall += 0;
            }
        return countFall;
     }

    public boolean canFall(){
        int count = 0;
        while(countFall > 0 && skyMonkey.getY() < 450){
            count ++;
            return true;
        }

        
        return false;
    }

    public void act(){
        //adds score if touches banana
        super.act();

        //locations of monkey
        int x = skyMonkey.getX();
        int y = skyMonkey.getY();

        if(y < 0){
            loseLife(1);
        }

        //displays lives OR moves to loser screen if out of lives
        if(lives >= 0){
            showText("Lives: " + lives, 10, 50, Color.BLACK);
        }
        else{
            EndLoseScreen lose = new EndLoseScreen();
            Mayflower.setWorld(lose);
        }

        //Checks if x>200 (if it is off the platform) so that the monkey can "fall"
        if(checkIfFalling(x) == 1){
            buildWorld();    //recreates the world but with flying clouds and bananas

        }
        //checks if countFall > 0 and y < 450 to prevent it from falling down off screen and sents the monkey falling 1 px at a time
        if(canFall()){
            skyMonkey.setLocation(x, y + 1); 
        }
        
        
        if (Mayflower.isKeyDown( Keyboard.KEY_RIGHT )) {
            skyMonkey.setLocation (x + 5, y);
        }
        else if (Mayflower.isKeyDown( Keyboard.KEY_LEFT )) {
            skyMonkey.setLocation(x - 5, y);
            skyMonkey.setWalkLeft();
        }
        else{
            skyMonkey.setIdle();
        }
        if(isStarted()){
            LandWorld land = new LandWorld();
            Mayflower.setWorld(land);
            start = false;
        }
        while((skyMonkey.isTouchingObject() == WorldObject.Cloud)&&(!Mayflower.isKeyDown(Keyboard.KEY_DOWN))){
            skyMonkey.setLocation(x, y - 3); 
        }
        if(skyMonkey.isTouchingObject() == WorldObject.Block){
            LandWorld land = new LandWorld();
            Mayflower.setWorld(land);
            start = false;
        }

    }
}


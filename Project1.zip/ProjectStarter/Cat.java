import mayflower.*;

public class Cat extends AnimatedActor
{
    private Animation walkRight;
    private Animation walkLeft;
    private Animation idle;
    private int locationX;
    private int locationY;

    public Cat(int x, int y) // the constructor takes two parameters for the x and y location of the character
    {
        locationX = x;
        locationY = y;
        setLocation(locationX, locationY);
        initAnimations();
    }
    private void initAnimations()
    {
        String[] filenames = new String[9];
        for (int i = 0; i < filenames.length; i++)
        {
            filenames[i] = "img/MonkeyAnim/sprite_" + i + ".png";
        }
        walkRight = new Animation(100, filenames);
        walkRight.scale(100,87);
        
        String[] filenamesLeft = new String[9];
        for (int i = 0; i < filenames.length; i++){
            filenames[i] = "img/MonkeyAnim/sprite_" + i + ".png";
            
        }
        walkLeft = new Animation(100, filenames);
        walkLeft.scale(100,87);
        walkLeft.mirrorHorizontally();
        
        String[] filenamesIdle = new String[2];
        filenamesIdle[0] = "img/MonkeyAnim/sprite_0.png";
        filenamesIdle[1] = "img/MonkeyAnim/sprite_0.png";
        idle = new Animation(300, filenamesIdle);
        idle.scale(100, 87);
        
        setAnimation(idle);

    }
    public void setWalkRight() //sets the character's animation to walking
    {
        if (getAnimation() != walkRight)
        {
            setAnimation(walkRight);
        }
    }
    public void setWalkLeft() //sets the character's animation to walking
    {
        if (getAnimation() != walkLeft)
        {
            setAnimation(walkLeft);
        }
    }
    public void setIdle() // sets the character's animation to idle
    {
        if (getAnimation() != idle)
        {
            setAnimation(idle);
        }
    }  
    

    public WorldObject isTouchingObject(){
        if (this.isTouching(Cloud.class)){
            return WorldObject.Cloud;
        }
        if (this.isTouching(Block.class)){
            return WorldObject.Block;
        }
        if (this.isTouching(Banana.class)){
            removeTouching(Banana.class);
            MyWorld.score++;
            return WorldObject.Banana;
        }
        if (this.isTouching(Crab.class)){
            removeTouching(Crab.class);
            SeaWorld.lives--;
            return WorldObject.Crab;
        }
        if (this.isTouching(Pig.class)){
            removeTouching(Pig.class);
            LandWorld.lives--;
            return WorldObject.Pig;
        }
        if (this.isTouching(Portal.class)){
            removeTouching(Portal.class);
            SeaWorld.didWin= true;
            return WorldObject.Portal;
        }
        if(isTouching(Cliff.class)){
            
            return WorldObject.Cliff;
            
        }
        return null;
    }
   
    
    public void act()
    {
        super.act();
        
    }
}



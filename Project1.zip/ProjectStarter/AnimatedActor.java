import mayflower.*;
public class AnimatedActor extends Actor
{
    // instance variables - replace the example below with your own
    private Animation animation;
    private Timer animationTimer;
    public AnimatedActor(){
        animation = null;
        animationTimer = new Timer(100);
    }   
    public Animation getAnimation()
    {
        return animation;
    }
    public void setAnimation(Animation a)
    {
        if (a == null)
        {
            return;
        }
        if (animation == a)
        {
            return;
        }
        animation = a;
        animation.reset();
        
        animationTimer = new Timer(animation.getFrameRate());
        
        setImage(animation.getCurrentFrame());
    }
    public void act()
    {
        if (animationTimer.isDone()){
            MayflowerImage p = animation.getNextFrame();
            setImage(p);
        }
    }
}



import mayflower.*;
/**
 * Write a description of class EndLoseScreen here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EndLoseScreen extends MyWorld
{
    private String text;

    public EndLoseScreen()
    {
        super(TypeWorld.Lose,"img/BG/GameOverScreen.png");     
        showText("YOU LOSE!!", 300, 150, Color.WHITE);
    }
  
    public void act()
    {
        if (Mayflower.isKeyDown(Keyboard.KEY_D)){
            GameOver game = new GameOver();
            Mayflower.setWorld(game);
            
        }
    }
}